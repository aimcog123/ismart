var express = require('express');
var router = express.Router();


var Twitter = require('twitter');
 
var client = new Twitter({
  consumer_key: 'xhYHNgFBulA750aSC4QZ76qzL',
  consumer_secret: '7isuCzJfvGDdpI1dQ5jQg02pGlWdixPT0adwxsDNXTHPdppg7k',
  access_token_key: '762886605837209600-6fPSsI40ClCcFyp7uHjIID3tvMss0aZ',
  access_token_secret: '9bz6uagylOBVmgC6W1fEsHch7MULs8ZBOSxG4ItNGrQ9F'
});
 

var watson = require('watson-developer-cloud');
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
  
});




router.get('/test', function(req, res) {
   
   
 
	var numTweets = 5;
	var tweetDescription = [];
	var tweetNLC = [];
	var outputResponse = [];

 // console.log("!!req:", req)
	var handle = req.query.handle;
    var params = {screen_name: handle};
    //var params = {q: handle};
    console.log("####handle: ", handle);
    client.get('search/tweets', {q: handle,count:'5',lang:"en"}, function(error, tweets, response) {
    //console.log(tweets)
    for (var i = 0; i < numTweets; i++) {
      
			//console.log(tweets[i]);
      tweet_text=tweets.statuses[i].text;
      //tweet_text=tweets.statuses[i].text.replace("/[^\x00-\x7F]/g", "");
      //tweet_text=tweets.statuses[i].text.replace(/[^\x20-\x7E]/g, '');
      tweet_text=tweets.statuses[i].text.replace(/^[\u0080-\uffff]/g, ""); 
			tweetDescription.push(tweet_text);
     
		}
/* 		getNLU(tweetDescription,function(response){
			//console.log("!!!response: ",response )
			outputResponse.push(response);
     console.log(outputResponse);
	 res.send(outputResponse);

	}); */
    getNLC(tweetDescription,function(response){
    outputResponse.push(response);
	//console.log(outputResponse);
    res.send(outputResponse);
    }); 
  //console.log("outputResponse:",outputResponse );
});


function getNLU(tweetDesc,cb){

var NaturalLanguageUnderstandingV1 = require('watson-developer-cloud/natural-language-understanding/v1.js');
var natural_language_understanding = new NaturalLanguageUnderstandingV1({
  'username': 'bf7a6b28-a7cb-4b07-9ca3-d0303f4ebc35',
  'password': 'CiHHmEuXCRh5',
 //    'username': '14e908b8-531b-4f90-a906-710fc0474bac',
 //    'password': 'e1K2iUmXjpiJ',
     'version_date': '2017-02-27'
});	

for (var i = 0; i < tweetDesc.length; i++) {

  var parameters = {
  'text':tweetDesc[i],
  'language':'en',
  'features': {
    'keywords': {
      'sentiment': true,
      'emotion': true,
      'limit': 3
    },
    'sentiment':{},
    'emotion':{}
  }
};
var ab=[];
natural_language_understanding.analyze(parameters, function(err, response) {
  
  if (err)
    console.log('error:', err);
  else
    
    //console.log(JSON.stringify(response, null, 2));
    //tweetNLU.push(JSON.stringify(response, null, 2));
	ab.push(JSON.stringify(response, null, 2));
	
  if(ab.length==5){
  cb(ab);
  }
  });

} 
}
function getNLC(tweetDesc,cb1){
var cd=[];
var natural_language_classifier = watson.natural_language_classifier({
  username: '5b2baaef-c578-4238-bca4-91597571c700',
  password: 'N4zHBhC4cfkm',
  version: 'v1'
});
for (var i = 0; i < tweetDesc.length; i++) {

natural_language_classifier.classify({
  text:tweetDescription[i],
  classifier_id: '715dfax190-nlc-475' },
  function(err, response) {
    if (err)
      console.log('error:', err);
    else{
      cd.push(JSON.stringify(response, null, 2));
      if(cd.length==5){
      cb1(cd)
      }
      }
});

} 
}

});
module.exports = router;