// Global variables
margin = width = height = "";
wcOpt = "";
animationDuration = 500;

$(document).ready(function() {
						   
    // Set chart height
    var chart_h = $(window).outerHeight() - $("header").outerHeight(true) - 100;
    $(".chart").css({
        height: chart_h + "px"
    });

    // Set chart margin
    margin = { top: 50, right: 0, bottom: 80, left: 0 };
    width = $(".chart").outerWidth(true) - margin.left - margin.right;
    height = $(".chart").outerHeight(true) - margin.top - margin.bottom;

    // Draw sentiment chart
    get_sentiment_content();

    // Get sentiment word
    get_sentiment_word("all");


    // Monitoring 
    $(".monitoring").click(function() {
        
		// Set active class
		$(".monitoring").removeClass("active");
        $(this).addClass("active");
		
		// show the main content
        $(".sentiment-cont, .emotion-cont, .intent-cont").hide();
        $("." + $(this).attr("data-opt") + "-cont").show();

		// show and hide the sidebar contnent
		$(".sidebar .box").hide();
		$(".sidebar .box."+ $(this).attr("data-opt") +"-sidebar").show();	
		
        switch ($(this).attr("data-opt")) {
            case 'emotion':
                 get_emotion_word("all");
				 get_emotion_content('all');
                break;
            case 'intent':
                get_intent_content('all');
                break;
            default:
                get_sentiment_content();
                get_sentiment_word("all");
        }
    });


    // Emotion - Right side bar - click handler
    $(".sentiment-wc").click(function() {
        // Remove all the active class
        $(".sentiment-wc").removeClass("active");
        // Set the active class
        $(this).addClass("active");
        $(".sentiment-wc[data-opt='" + $(this).attr("data-opt") + "']").addClass("active");
        // Get sentiment word
        get_sentiment_word($(this).attr("data-opt"));
        get_sentiment_content($(this).attr("data-opt"));
    });
	
	 $(".emotion-wc").click(function() {
        // Remove all the active class
        $(".emotion-wc").removeClass("active");
        // Set the active class
        $(this).addClass("active");
        $(".emotion-wc[data-opt='" + $(this).attr("data-opt") + "']").addClass("active");
        // Get sentiment word
        get_emotion_word($(this).attr("data-opt"));
		get_emotion_content($(this).attr("data-opt"));
    });
	 
	  $(".intent-wc").click(function() {
        // Remove all the active class
        $(".intent-wc").removeClass("active");
        // Set the active class
        $(this).addClass("active");
        $(".intent-wc[data-opt='" + $(this).attr("data-opt") + "']").addClass("active");
        // Get sentiment word
        get_intent_content($(this).attr("data-opt"));
    });

    //$(".monitoring").eq(2).trigger("click");

});


/**
 * Function: Get emotion content
 */
function get_sentiment_content(opt){
    var positive = [],
        negative = [],
        neutral = [];

    //var url = localhost/getTweetLevel

    $.get("data/TweetLevel.json", function(data) {

        // Check data is not null
        if ((data === undefined) && (data.length == 0)) {
            return null;
        }

        for (var i = 0; i < data.length; i++) {
            if (data[i].sentiment.document !== undefined) {
                var se = data[i].sentiment.document;
                if(se.label == "positive"){
                    positive.push([se.score, i]);
                }
                else if(se.label == "negative"){
                    negative.push([se.score, i]);
                }
                else{
                    neutral.push([se.score, i]);
                }
            }
        }

        positive = {
            "data": positive,
            "label": "Positive",
            "color": getColor("", 20, "positive")
        };
        negative = {
            "data": negative,
            "label": "Negative",
            "color": getColor("", 20, "negative")
        };
        neutral = {
            "data": neutral,
            "label": "Neutral",
            "color": getColor("", 20, "neutral")
        };
        
        var iData = [];
        switch (opt) {
            case "positive":
                iData[0] = positive;
            break;
            case "negative":
                iData[0] = negative;
            break;
            case "neutral":
                iData[0] = neutral;
            break;
            default: 
                iData[0] = positive;
                iData[1] = negative;
                iData[2] = neutral;
        }

        draw_sentiment_chart(iData);
        
    });
}

/**
 * Function: Draw sentiment chart
 */
function draw_sentiment_chart(data){
    chart = d3LineWithLegend()
        .xAxis.label('Sentiment Score')
        .width(width(margin))
        .height(height(margin))
        .yAxis.label('Tweets count');

    d3.select("#sentiment-chart").select("svg").remove();

    var svg = d3.select("#sentiment-chart").append("svg")
        .datum(data)
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.transition().duration(animationDuration)
        .attr("width", width(margin))
        .attr("height", height(margin))
        .call(chart);

    // Remove the first tick text in the y axix
    svg.selectAll(".y.axis").selectAll(".tick").each(function (d, i) {
        if ( d == 0 ) {
            this.remove();
        }
    });

    // Middle align the y axis
    //svg.select('.y.axis').attr("transform", "translate(" + (svg.node().getBoundingClientRect().width / 2 ) + ", 0)");

    chart.dispatch.on('showTooltip', function(e) {
        var offset = $('#sentiment-chart').offset(), // { left: 0, top: 0 }
            left = e.pos[0] + offset.left,
            top = e.pos[1] + offset.top,
            formatter = d3.format(".04f");

        var content = '<h3>' + e.series.label + '</h3>' +
            '<p>' +
            '<span class="value">[' + formatter(e.point[1]) + ', ' + e.point[0] + ']</span>' +
            '</p>';

        nvtooltip.show([left, top], content, "s", -15, e.series.label.toLowerCase());
    });

    chart.dispatch.on('hideTooltip', function(e) {
        nvtooltip.cleanup();
    });

    function width(margin) {
        return $(".main-content #sentiment-chart").outerWidth(true) - margin.left - margin.right;
    }

    function height(margin) {
        return $(".main-content #sentiment-chart").outerHeight(true) - margin.top - margin.bottom;
    }

}

/**
 * Function: Draw sentiment chart
 */
/*function draw_sentiment_chart() {
    d3.json("data/sample-1.json", function(error, data) {

        data.forEach(function(d) {
            d.x = +d.x;
            d.y = +d.y;
        });

        var x = d3.scale.linear()
            .range([0, width - margin.left - margin.right]);

        var y = d3.scale.linear()
            .range([height - margin.top - margin.bottom, 0]);

        var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom");

        var yAxis = d3.svg.axis()
            .scale(y)
            .orient("left");

        var line = d3.svg.line()
            .interpolate(interpolateSankey)
            .x(function(d) {
                return x(d.x);
            })
            .y(function(d) {
                return y(d.y);
            });

        d3.select("#sentiment-chart").select("svg").remove();

        var svg = d3.select("#sentiment-chart").append("svg")
            .attr("width", width)
            .attr("height", height)
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        x.domain(d3.extent(data, function(d) {
            return d.x;
        }));
        y.domain(d3.extent(data, function(d) {
            return d.y;
        }));

        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + (height - margin.top - margin.bottom) + ")")
            .call(xAxis);

        svg.append("g")
            .attr("class", "y axis")
            .attr("transform", "translate(" + ((width - margin.left - margin.right) / 2) + ", 0)")
            .call(yAxis);

        svg.append("path")
            .datum(data)
            .attr("class", "line")
            .attr("d", line);

        //update(root);
    });
}
*/

/**
 * Function get the sentiment word
 */
function get_sentiment_word(opt) {
    wcOpt = opt;
    $.get("data/NLUoutput.json", function(data) {

        // Check data is not null
        if ((data === undefined) && (data.length == 0)) {
            return null;
        }

        // Prepare word cloud json
        var wCloud = [];
        for (var i = 0; i < data.length; i++) {
            //console.log(data[i].keywords);
            if (data[i].keywords.length > 0) {
                for (var key = 0; key < data[i].keywords.length; key++) {

                    //console.log(data[i].keywords[key]);
                    var size = parseInt(data[i].keywords[key].sentiment.score * 10);
                    if (data[i].keywords[key].sentiment.score < 0) {
                        size = size * -1;
                    }
                    if (data[i].keywords[key].sentiment.score == 0) {
                        size = 3;
                    }
                    size = (size + 2) * 2; // Add Extra font size

                    switch (opt) {
                        case 'positive':
                            if (data[i].keywords[key].sentiment.score > 0) {
                                wCloud.push({
                                    word: capitalize(data[i].keywords[key].text),
                                    weight: size
                                });
                            }
                            break;
                        case 'negative':
                            if (data[i].keywords[key].sentiment.score < 0) {
                                wCloud.push({
                                    word: capitalize(data[i].keywords[key].text),
                                    weight: size
                                });
                            }
                        case 'neutral':
                            if (data[i].keywords[key].sentiment.score == 0) {
                                wCloud.push({
                                    word: capitalize(data[i].keywords[key].text),
                                    weight: size
                                });
                            }
                            break;
                        default:
                            wCloud.push({
                                word: capitalize(data[i].keywords[key].text),
                                weight: size
                            });
                    }

                }
            }
        }
        prepare_sentiment_wordcloud(wCloud);
    });
}

/**
 * Function prepare sentiment wordcloud
 */
function prepare_sentiment_wordcloud(data) {

    //var data = [{word:"Hello",weight:20},{word:"World",weight:10},{word:"Normally",weight:25},{word:"You",weight:15},{word:"Want",weight:30},{word:"More",weight:12},{word:"Words",weight:8},{word:"But",weight:18},{word:"Who",weight:22},{word:"Cares",weight:27}];

    var xScale = d3.scale.linear()
    .domain([0, d3.max(data, function(d) {
        return d.weight;
        })
    ])
    .range([1,30]);

    d3.layout.cloud().size([width, height])
        .timeInterval(animationDuration)
        .words(data.map(function(d) {
            return {
                text: d.word,
                size: d.weight
            };
        }))
        .padding(0)
        .rotate(function(d) {
            //return ~~(Math.random() * 2) * 90;
            return (~~(Math.random() * 6) - 3) * 30;
            //return 0;
        })
        .font("Impact")
        .fontSize(function(d) {
            return xScale(d.size);
        })
        .spiral("archimedean")
        .on("end", draw_sentiment_wordcloud)
        .start();

}

/**
 * Function Draw sentiment wordcloud
 */
function draw_sentiment_wordcloud(cloud, tags, bounds) {

    // Remove the existing svg
    d3.select("#sentiment-wordcloud").select("svg").remove();

    // Draw the svg
    d3.select("#sentiment-wordcloud").append("svg")
        .attr("width", width)
        .attr("height", height + 120)
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        .append("g")
        .attr("transform", "translate(" + (width / 2) + "," + (height / 2) + ")")
        .selectAll("text")
        .data(cloud)
        .enter().append("text")
        .style("font-size", function(d) {
            return d.size + "px";
        })
        .style("font-family", "Impact")
        .style("fill", function(d, i) {
            return getColor(d, i);
        })
        .attr("text-anchor", "middle")
        .attr("transform", function(d) {
            return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
        })
        .text(function(d) {
            return d.text;
        });
        //.spiral("archimedean");
}


/**
 * Function : Get emotion word
 */
function get_emotion_word(opt){
	wcOpt = opt;
	$.get("data/NLUoutput.json", function(data) {

        // Check data is not null
        if ((data === undefined) && (data.length == 0)) {
            return null;
        }

        // Prepare word cloud json
        var wCloud = [];
        for (var i = 0; i < data.length; i++) {
            //console.log(data[i].keywords);
            if (data[i].keywords.length > 0) {
                for (var key = 0; key < data[i].keywords.length; key++) {
					
					switch(opt){
						case "anger":
							if(data[i].keywords[key].emotion !== undefined){
								var size = (data[i].keywords[key].emotion.anger !== undefined) ? data[i].keywords[key].emotion.anger : 0;
								wCloud.push({
										word: capitalize(data[i].keywords[key].text),
										weight: size
									});
							}
						break;
						case "joy":
							if(data[i].keywords[key].emotion !== undefined){
								var size = (data[i].keywords[key].emotion.joy !== undefined) ? data[i].keywords[key].emotion.joy : 0;
								wCloud.push({
										word: capitalize(data[i].keywords[key].text),
										weight: size
									});
							}
						break;
						case "fear":
							if(data[i].keywords[key].emotion !== undefined){
								var size = (data[i].keywords[key].emotion.fear !== undefined) ? data[i].keywords[key].emotion.fear : 0;
								wCloud.push({
										word: capitalize(data[i].keywords[key].text),
										weight: size
									});
							}
						break;
						case "sadness":
							if(data[i].keywords[key].emotion !== undefined){
								var size = (data[i].keywords[key].emotion.sadness !== undefined) ? data[i].keywords[key].emotion.sadness : 0;
								wCloud.push({
										word: capitalize(data[i].keywords[key].text),
										weight: size
									});
							}
						break;
						case "disgust":
							if(data[i].keywords[key].emotion !== undefined){
								var size = (data[i].keywords[key].emotion.disguist !== undefined) ? data[i].keywords[key].emotion.disguist : 0;
								wCloud.push({
										word: capitalize(data[i].keywords[key].text),
										weight: size
									});
							}
						break;
						default:
							if(data[i].keywords[key].emotion !== undefined){
								var size = (data[i].keywords[key].emotion.anger !== undefined) ? data[i].keywords[key].emotion.anger : 0;
									size = +(data[i].keywords[key].emotion.joy !== undefined) ? data[i].keywords[key].emotion.joy : 0;
									size = +(data[i].keywords[key].emotion.fear !== undefined) ? data[i].keywords[key].emotion.fear : 0;
									size = +(data[i].keywords[key].emotion.sadness !== undefined) ? data[i].keywords[key].emotion.sadness : 0;
									size = +(data[i].keywords[key].emotion.disguist !== undefined) ? data[i].keywords[key].emotion.disguist : 0;
									
								wCloud.push({
											word: capitalize(data[i].keywords[key].text),
											weight: getFontWCFontSize(size)
										});
							}
					}
                    
                }
            }
        }
        prepare_emotion_wordcloud(wCloud);
    });
}

/**
 * Function: prepare emotion wordcloud
 */
function prepare_emotion_wordcloud(data) {

    var xScale = d3.scale.linear()
    .domain([0, d3.max(data, function(d) {
        return d.weight;
        })
    ])
    .range([10,30]);

    d3.layout.cloud().size([width, height])
        .timeInterval(animationDuration)
        .words(data.map(function(d) {
            return {
                text: d.word,
                size: d.weight
            };
        }))
        .padding(0)
        .rotate(function(d) {
            //return ~~(Math.random() * 2) * 90;
            return (~~(Math.random() * 6) - 3) * 30;
            //return 0;
        })
        .font("Impact")
        .fontSize(function(d) {
            return xScale(d.size);
        })
        .spiral("archimedean")
        .on("end", draw_emotion_wordcloud)
        .start();

}

/**
 * Function: Draw emotion word cloud
 */
function draw_emotion_wordcloud(cloud, tags, bounds) {

    // Remove the existing svg
    d3.select("#emotion-wordcloud").select("svg").remove();

    // Draw the svg
    d3.select("#emotion-wordcloud").append("svg")
        .attr("width", width)
        .attr("height", height)
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        .append("g")
        .attr("transform", "translate(" + (width / 2) + "," + (height / 2) + ")")
        .selectAll("text")
        .data(cloud)
        .enter().append("text")
        .style("font-size", function(d) {
            return d.size + "px";
        })
        .style("font-family", "Impact")
        .style("fill", function(d, i) {
            return getColor(d, i);
        })
        .attr("text-anchor", "middle")
        .attr("transform", function(d) {
            return "translate(" + [d.x, d.y] + ")rotate(" + d.rotate + ")";
        })
        .text(function(d) {
            return d.text;
        });
}

/**
 * Function: Get emotion content
 */
function get_emotion_content(opt){
	var anger = [],
        joy = [],
        sadness = [],
        fear = [],
        disgust = [];

    $.get("data/TweetLevel.json", function(data) {

        // Check data is not null
        if ((data === undefined) && (data.length == 0)) {
            return null;
        }

		for (var i = 0; i < data.length; i++) {
            if (data[i].emotion.document.emotion !== undefined) {
				var em = data[i].emotion.document.emotion;
				if(em.anger !== undefined){
					anger.push([em.anger, i]);
				}
				if(em.joy !== undefined){
					joy.push([em.joy, i]);
				}
				if(em.sadness !== undefined){
					sadness.push([em.sadness, i]);
				}
				if(em.fear !== undefined){
					fear.push([em.fear, i]);
				}
				if(em.disgust !== undefined){
					disgust.push([em.disgust, i]);
				}
            }
        }

		anger = {
            "data": anger,
            "label": "Anger",
            "color": getColor("", 20, "anger")
        };
        joy = {
            "data": joy,
            "label": "Joy",
            "color": getColor("", 20, "joy")
        };
        sadness = {
            "data": sadness,
            "label": "Sadness",
            "color": getColor("", 20, "sadness")
        };
        fear = {
            "data": fear,
            "label": "Fear",
            "color": getColor("", 20, "fear")
        };
        disgust = {
            "data": disgust,
            "label": "Disgust",
            "color": getColor("", 20, "disgust")
        };
		
		var iData = [];
		switch (opt) {
			case "anger":
				iData[0] = anger;
			break;
			case "joy":
				iData[0] = joy;
			break;
			case "sadness":
				iData[0] = sadness;
			break;
			case "fear":
				iData[0] = fear;
			break;
			case "disgust":
				iData[0] = disgust;
			break;
			default: 
				iData[0] = anger;
				iData[1] = joy;
				iData[2] = sadness;
				iData[3] = fear;
				iData[4] = disgust;
		}
		
        draw_emotion_chart(iData);
    });
}

/**
 * Function: Draw emotion chart
 */
function draw_emotion_chart(data){
    chart = d3LineWithLegend()
        .xAxis.label('Emotion Score')
        .width(width(margin))
        .height(height(margin))
        .yAxis.label('Tweets count');

    d3.select("#emotion-chart").select("svg").remove();

    var svg = d3.select("#emotion-chart").append("svg")
        .datum(data)
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.transition().duration(animationDuration)
        .attr("width", width(margin))
        .attr("height", height(margin))
        .call(chart);


    chart.dispatch.on('showTooltip', function(e) {
        var offset = $('#emotion-chart').offset(), // { left: 0, top: 0 }
            left = e.pos[0] + offset.left,
            top = e.pos[1] + offset.top,
            formatter = d3.format(".04f");

        var content = '<h3>' + e.series.label + '</h3>' +
            '<p>' +
            '<span class="value">[' + formatter(e.point[1]) + ', ' + e.point[0] + ']</span>' +
            '</p>';

        nvtooltip.show([left, top], content, "s", -15, e.series.label.toLowerCase());
    });

    chart.dispatch.on('hideTooltip', function(e) {
        nvtooltip.cleanup();
    });

    function width(margin) {
        return $(".main-content #emotion-chart").outerWidth(true) - margin.left - margin.right;
    }

    function height(margin) {
        return $(".main-content #emotion-chart").outerHeight(true) - margin.top - margin.bottom;
    }

}

/**
 * Function: Get intent content
 */
function get_intent_content(opt) {

    var complaint = [],
        needHelp = [],
        praise = [],
        purchase = [],
        others = [];

    $.get("data/watson.json", function(data) {

        // Check data is not null
        if ((data === undefined) && (data.length == 0)) {
            return null;
        }

        for (var i = 0; i < data.length; i++) {
            if (data[i].classes.length > 0) {
                data[i].classes.forEach(function(d) {
					if (d["class_name"].toLowerCase() == "complaint") {
						complaint.push([d["confidence"], i]);
					}
					if (d["class_name"].toLowerCase() == "needhelp") {
						needHelp.push([d["confidence"], i]);
					}
					if (d["class_name"].toLowerCase() == "praise") {
						praise.push([d["confidence"], i]);
					}
					if (d["class_name"].toLowerCase() == "purchase") {
						purchase.push([d["confidence"], i]);
					}
					if (d["class_name"].toLowerCase() == "others") {
						others.push([d["confidence"], i]);
					}
                });
            }
        }

		complaint = {
            "data": complaint,
            "label": "Complaint",
            "color": getColor("", 20, "complaint")
        };
        needHelp = {
            "data": needHelp,
            "label": "NeedHelp",
            "color": getColor("", 20, "needhelp")
        };
        praise = {
            "data": praise,
            "label": "Praise",
            "color": getColor("", 20, "praise")
        };
        purchase = {
            "data": purchase,
            "label": "Purchase",
            "color": getColor("", 20, "purchase")
        };
        others = {
            "data": others,
            "label": "Others",
            "color": getColor("", 20, "others")
        };
		
		var iData = [];
		switch (opt) {
			case "complaint":
				iData[0] = complaint;
			break;
			case "needhelp":
				iData[0] = needHelp;
			break;
			case "praise":
				iData[0] = praise;
			break;
			case "purchase":
				iData[0] = purchase;
			break;
			case "others":
				iData[0] = others;
			break;
			default: 
				iData[0] = complaint;
				iData[1] = needHelp;
				iData[2] = praise;
				iData[3] = purchase;
				iData[4] = others;
		}

        draw_intent_chart(iData);
        //var iData = generateIntentSampeleData();
        //draw_intent_chart(iData);
    });
}

/**
 * Function: Draw intent linear chart
 */
function draw_intent_chart(data) {
    chart = d3LineWithLegend()
        .xAxis.label('Intent Score')
        .width(width(margin))
        .height(height(margin))
        .yAxis.label('Tweets count');

    d3.select("#intent-chart").select("svg").remove();

    var svg = d3.select("#intent-chart").append("svg")
        .datum(data)
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.transition().duration(animationDuration)
        .attr("width", width(margin))
        .attr("height", height(margin))
        .call(chart);


    chart.dispatch.on('showTooltip', function(e) {
        var offset = $('#intent-chart').offset(), // { left: 0, top: 0 }
            left = e.pos[0] + offset.left,
            top = e.pos[1] + offset.top,
            formatter = d3.format(".04f");

        var content = '<h3>' + e.series.label + '</h3>' +
            '<p>' +
            '<span class="value">[' + formatter(e.point[1]) + ', ' + e.point[0] + ']</span>' +
            '</p>';

        nvtooltip.show([left, top], content, "s", -15, e.series.label.toLowerCase());
    });

    chart.dispatch.on('hideTooltip', function(e) {
        nvtooltip.cleanup();
    });

    function width() {
        return $(".main-content #intent-chart.chart").outerWidth(true) - margin.left - margin.right + 200;
    }

    function height(margin) {
        return $(".main-content #intent-chart.chart").outerHeight(true) - margin.top - margin.bottom;
    }

}

/*********** Util functions ***********/

/**
 * Function: Get radious path
 */
function interpolateSankey(points) {
    var x0 = points[0][0],
        y0 = points[0][1],
        x1, y1, x2,
        path = [x0, ",", y0],
        i = 0,
        n = points.length;
    while (++i < n) {
        x1 = points[i][0], y1 = points[i][1], x2 = (x0 + x1) / 2;
        path.push("C", x2, ",", y0, " ", x2, ",", y1, " ", x1, ",", y1);
        x0 = x1, y0 = y1;
    }
    return path.join("");
}

/**
 * Function: Get the font size based on the weight
 */
function getFontWCFontSize(size){
    /*var newSize = parseInt(size * 10);
    if (newSize < 0) {
        newSize = newSize * -1;
    }
    if (newSize == 0) {
        newSize = 3;
    }*/
    return size;
}

/**
 * Function : Get the word cloud font color based on the score
 */
var fill = d3.scale.category20();
function getColor(d, i, pref){
    //;var fill = d3.scale.category20();
   // console.log(wcOpt);
    var rgb = "",
        size = "";

    if(pref !== undefined){
        wcOpt = pref;
        size = 20;
    }
    else{
        size = d.size * 3
    }

    switch(wcOpt){
        /* Sentiment WC colors */
        case "positive":
            rgb = "rgb("+ (10 + size) +", "+ (200 + size) +", "+ (10 + size) +")";
            break;
        case "negative":
            rgb = "rgb("+ (200 + size) +", 10, 10)";
            break;
        case "neutral":
            rgb = "rgb(10, 155, "+ (200 + size) +")";
            break;
        case "all":
            rgb = "rgb("+ (1 + size) +", "+ (80 + size) +", "+ (220 + size) +")";
            break;

        /* Emotion WC colors */
        case "anger":
            rgb = "rgb("+ (200 + size) +", 10, 10)";
            break;
        case "joy":
            rgb = "rgb("+ (220 + size) +", "+ (50 + size) +", "+ (220 + size) +")";
            //rgb = fill(i);
            break;
        case "fear":
            rgb = "rgb("+ (50 + size) +", "+ (100 + size) +", "+ (50 + size) +")";
            break;
        case "sadness":
            rgb = "rgb("+ (100 + size) +", "+ (100 + size) +", "+ (100 + size) +")";
            break;
        case "disgust":
            rgb = "rgb("+ (100 + size) +", 0, "+ (250 + size) +")";
            break;

        /* Intent Line colors */
         case "complaint":
            rgb = "rgb("+ (50 + size) +", 150, 255)";
            break;
        case "needhelp":
            rgb = "rgb("+ (220 + size) +", "+ (50 + size) +", "+ (220 + size) +")";
            //rgb = fill(i);
            break;
        case "praise":
            rgb = "rgb("+ (50 + size) +", "+ (100 + size) +", "+ (50 + size) +")";
            break;
        case "purchase":
            rgb = "rgb(255, 127, 14)";
            break;
        case "others":
            rgb = "rgb("+ (100 + size) +", 0, "+ (250 + size) +")";
            break;

        default:
            rgb = "rgb(0, 102, "+ (200 + size) +")";
    }

    return rgb;
}

// Function make word as capitalize
function capitalize(s) {
    return s.replace(/\S/, function(m) {
        return m.toUpperCase();
    });
}

// Generate sample data for linear chart
function generateIntentSampeleData() {
    var sin = [],
        sin2 = [],
        cos = [],
        cos2 = [],
        cos3 = [],

        r1 = Math.random(),
        r2 = Math.random(),
        r3 = Math.random(),
        r4 = Math.random();
    r5 = Math.random();

    for (var i = 6; i > 0; i--) {
        //sin.push([r1 * Math.sin(r2 + i / (10 * (r5 + .5))), i]);
        //cos.push([r2 * Math.cos(r3 + i / (10 * (r3 + .5))), i]);
        //sin2.push([r3 * Math.sin(r1 + i / (10 * (r4 + .5))), i]);
        //cos2.push([r4 * Math.cos(r4 + i / (10 * (r1 + .5))), i]);
        //cos3.push([r5 * Math.cos(r5 + i / (10 * (r2 + .5))), i]);
    }

    sin.push([0.2, 200]);
    sin.push([0.1, 50]);
    sin.push([0.37, 10]);
    sin.push([0.4, 25]);

    cos.push([0.2, 300]);
    cos.push([0.25, 100]);
    cos.push([0.37, 50]);
    cos.push([0.4, 50]);

    sin2.push([0.25, 180]);
    sin2.push([0.35, 90]);
    sin2.push([0.45, 20]);
    sin2.push([0.5, 25]);

    cos2.push([0.21, 150]);
    cos2.push([0.22, 70]);
    cos2.push([0.33, 50]);
    cos2.push([0.44, 60]);

    cos3.push([0.18, 300]);
    cos3.push([0.25, 80]);
    cos3.push([0.28, 60]);
    cos3.push([0.4, 20]);

    return [{
        data: sin,
        label: "Complaint"
    }, {
        data: cos,
        label: "NeedHelp"
    }, {
        data: sin2,
        label: "Praise"
    }, {
        data: cos2,
        label: "Purchase"
    }, {
        data: cos3,
        label: "Others"
    }];
}